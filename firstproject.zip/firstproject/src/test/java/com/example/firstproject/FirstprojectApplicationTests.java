package com.example.firstproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
